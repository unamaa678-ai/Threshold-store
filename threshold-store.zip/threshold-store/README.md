# Threshold — E-commerce Store

A single-page e-commerce site with a 3D animated door-entry front page.

## How to use
1. Unzip this folder.
2. Open `index.html` in any web browser (double-click it, or right-click → Open With → your browser).
3. An internet connection is needed the first time it loads, to fetch the Google Fonts (Fraunces, Inter, IBM Plex Mono). Everything else works fully offline.

## What's inside
- `index.html` — the entire site (HTML, CSS, and JavaScript in one file). No build tools, servers, or installs required.

## Features
- Animated 3D door entrance on the homepage — tap/click to "walk into" the shop
- 28-item catalog across 4 categories, filterable
- Product detail view with Add to Cart
- Shopping cart drawer with quantity controls
- Checkout flow with Cash on Delivery, Mastercard, and Visa options
- Footer with social links (Instagram, TikTok, Facebook, Pinterest, WhatsApp) and "All Rights Reserved"
- All prices shown are inclusive of shipping

## Notes for going live
- Product images are minimalist icon placeholders — swap in real product photography.
- The checkout is visual only; connect a real payment processor (e.g. Stripe, PayPal) or an e-commerce backend (e.g. Shopify) to actually process orders.
- To host it, upload `index.html` to any web host (Netlify, Vercel, GitHub Pages, your own server, etc.) or use it as the base for a multi-page build.
